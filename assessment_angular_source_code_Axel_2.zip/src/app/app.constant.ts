export const baseUrl = 'https://hacker-news.firebaseio.com/v0';
export const storiesUrl = `${baseUrl}/askstories.json`;

// https://hacker-news.firebaseio.com/v0/askstories.json
// https://hacker-news.firebaseio.com/v0/item/id.json;
